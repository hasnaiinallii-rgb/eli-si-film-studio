//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CMM0EY6p.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BQRAXJmS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BQRAXJmS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-QJst_kTr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
