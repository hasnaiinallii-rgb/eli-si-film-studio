import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B-ovqI0H.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var studioStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("a0eaaecac1ceaf6fd7292a87d405d9505991ebc2a46d4ccf0c3ff7bde2c02811"));
var writeScript = createServerFn({ method: "POST" }).validator((input) => {
	const idea = String(input?.idea ?? "").trim().slice(0, 600);
	const seconds = [
		15,
		30,
		45,
		60
	].includes(Number(input?.seconds)) ? Number(input.seconds) : 30;
	const style = String(input?.style ?? "cinematic").slice(0, 40);
	if (idea.length < 8) throw new Error("Describe the film in a sentence or two.");
	return {
		idea,
		seconds,
		style
	};
}).handler(createSsrRpc("391feb01f24590587bc09bfb2d2946053c8f3d2de922fa0d6f7e69aef39510c9"));
var W = 1280;
var H = 720;
var SKY = {
	dawn: [
		"#2b3a67",
		"#d98e73",
		"#ffd8a8"
	],
	day: [
		"#3d7ec9",
		"#8ec5f0",
		"#e7f4ff"
	],
	dusk: [
		"#24183f",
		"#c2506b",
		"#ffb36b"
	],
	night: [
		"#050712",
		"#0c1636",
		"#1a2758"
	]
};
function clamp(v, a, b) {
	return Math.min(b, Math.max(a, v));
}
function ease(t) {
	return t * t * (3 - 2 * t);
}
function hash(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function timeline(film) {
	const segs = [];
	let t = 0;
	segs.push({
		kind: "title",
		t0: t,
		t1: t += 3
	});
	for (const shot of film.shots) segs.push({
		kind: "shot",
		shot,
		t0: t,
		t1: t += shot.dur
	});
	segs.push({
		kind: "end",
		t0: t,
		t1: t += 3
	});
	return {
		segs,
		total: t
	};
}
function sky(ctx, time) {
	const [a, b, c] = SKY[time];
	const g = ctx.createLinearGradient(0, 0, 0, H);
	g.addColorStop(0, a);
	g.addColorStop(.55, b);
	g.addColorStop(1, c);
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, W, H);
	if (time === "night" || time === "dusk") {
		ctx.fillStyle = "rgba(255,255,255,0.85)";
		for (let i = 0; i < 40; i++) {
			const x = i * 97 % W;
			const y = i * 53 % (H * .55);
			ctx.globalAlpha = .3 + i * 17 % 7 / 10;
			ctx.fillRect(x, y, i % 5 === 0 ? 2 : 1, i % 5 === 0 ? 2 : 1);
		}
		ctx.globalAlpha = 1;
	}
}
function ground(ctx, place, time) {
	const y = H * .72;
	ctx.fillStyle = time === "day" || time === "dawn" ? "#2c3330" : "#0b0d12";
	if (place === "field") ctx.fillStyle = time === "night" ? "#142016" : "#3d6b3a";
	if (place === "space") ctx.fillStyle = "#05060c";
	ctx.fillRect(0, y, W, 201.60000000000002);
	ctx.strokeStyle = "rgba(255,255,255,0.06)";
	ctx.beginPath();
	ctx.moveTo(0, y);
	ctx.lineTo(W, y);
	ctx.stroke();
}
function city(ctx, t, wet, accent) {
	const base = H * .72;
	for (let i = 0; i < 14; i++) {
		const x = (i * 110 - t * 18 % 110) % 1420 - 40;
		const h = 90 + i * 47 % 220;
		ctx.fillStyle = i % 2 ? "#12151c" : "#1a1f2b";
		ctx.fillRect(x, base - h, 78, h);
		ctx.fillStyle = accent;
		for (let wy = base - h + 12; wy < 508.4; wy += 18) for (let wx = x + 10; wx < x + 68; wx += 16) {
			ctx.globalAlpha = (i + wy + Math.floor(t)) % 5 === 0 ? .9 : .25;
			ctx.fillRect(wx, wy, 8, 6);
		}
		ctx.globalAlpha = 1;
	}
	if (wet) {
		ctx.fillStyle = "rgba(120,160,255,0.18)";
		ctx.fillRect(0, base, W, 18);
		for (let i = 0; i < 80; i++) {
			const x = (i * 37 + t * 420) % W;
			const y = (i * 91 + t * 260) % (H * .45) + 20;
			ctx.strokeStyle = "rgba(200,220,255,0.35)";
			ctx.beginPath();
			ctx.moveTo(x, y);
			ctx.lineTo(x - 2, y + 14);
			ctx.stroke();
		}
	}
}
function field(ctx, t) {
	const base = H * .72;
	ctx.fillStyle = "#1d3a22";
	for (let i = 0; i < 60; i++) {
		const x = (i * 28 + Math.sin(t + i) * 4) % W;
		ctx.beginPath();
		ctx.moveTo(x, base);
		ctx.quadraticCurveTo(x + 6, 490.4, x + Math.sin(t * 2 + i) * 8, 472.4);
		ctx.strokeStyle = i % 2 ? "#6ea85a" : "#2f6a38";
		ctx.stroke();
	}
}
function interior(ctx, accent) {
	ctx.fillStyle = "#1a1410";
	ctx.fillRect(80, 80, 1120, H * .72 - 80);
	ctx.strokeStyle = accent;
	ctx.globalAlpha = .5;
	ctx.strokeRect(100, 100, 1080, H * .72 - 120);
	ctx.globalAlpha = 1;
	ctx.fillStyle = "#3a2a18";
	ctx.fillRect(160, H * .5, 220, H * .72 - H * .5);
	const g = ctx.createRadialGradient(W * .7, 160, 10, W * .7, 200, 280);
	g.addColorStop(0, "rgba(255,196,120,0.35)");
	g.addColorStop(1, "rgba(0,0,0,0)");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, W, H);
}
function space(ctx, t) {
	ctx.fillStyle = "#070912";
	ctx.fillRect(0, 0, W, H);
	ctx.fillStyle = "#fff";
	for (let i = 0; i < 90; i++) {
		const x = (i * 137 + t * (8 + i % 5)) % W;
		const y = i * 89 % H;
		ctx.globalAlpha = .3 + i % 5 / 8;
		ctx.fillRect(x, y, 2, 2);
	}
	ctx.globalAlpha = 1;
	ctx.fillStyle = "#c9b6ff";
	ctx.beginPath();
	ctx.arc(W * .78, H * .28, 70, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = "#070912";
	ctx.beginPath();
	ctx.arc(1026.4, H * .28 - 8, 58, 0, Math.PI * 2);
	ctx.fill();
}
function actor(ctx, kind, x, y, phase, accent) {
	ctx.save();
	ctx.translate(x, y);
	if (kind === "robot") {
		ctx.fillStyle = "#8d939c";
		ctx.fillRect(-22, -78, 44, 52);
		ctx.fillStyle = accent;
		ctx.fillRect(-14, -64, 28, 10);
		ctx.fillStyle = "#5c636c";
		ctx.fillRect(-26, -26, 52, 36);
		const swing = Math.sin(phase) * 10;
		ctx.fillRect(-30, -20 + swing, 8, 28);
		ctx.fillRect(22, -20 - swing, 8, 28);
		ctx.fillRect(-16, 10, 10, 26 + Math.abs(swing));
		ctx.fillRect(6, 10, 10, 26 + Math.abs(swing) * .4);
		ctx.fillStyle = "#c5ccd4";
		ctx.fillRect(-8, -92, 16, 14);
	} else if (kind === "cat") {
		ctx.fillStyle = "#9aa0a8";
		ctx.beginPath();
		ctx.ellipse(0, -18, 28, 14, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.beginPath();
		ctx.arc(22, -30, 12, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#6e747c";
		ctx.beginPath();
		ctx.moveTo(14, -40);
		ctx.lineTo(18, -52);
		ctx.lineTo(26, -40);
		ctx.fill();
		ctx.beginPath();
		ctx.moveTo(24, -38);
		ctx.lineTo(32, -50);
		ctx.lineTo(34, -36);
		ctx.fill();
		ctx.strokeStyle = "#9aa0a8";
		ctx.beginPath();
		ctx.moveTo(-24, -18);
		ctx.quadraticCurveTo(-40, -40 + Math.sin(phase) * 8, -18, -8);
		ctx.stroke();
		ctx.fillStyle = accent;
		ctx.fillRect(26, -32, 3, 3);
	} else if (kind === "bird") {
		ctx.strokeStyle = accent;
		ctx.lineWidth = 3;
		const f = Math.sin(phase * 2) * 16;
		ctx.beginPath();
		ctx.moveTo(-20, f);
		ctx.quadraticCurveTo(0, -18, 20, -f);
		ctx.stroke();
		ctx.lineWidth = 1;
	} else {
		ctx.fillStyle = "#e6d3c2";
		ctx.beginPath();
		ctx.arc(0, -78, 12, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = accent;
		ctx.fillRect(-12, -64, 24, 36);
		const swing = Math.sin(phase) * 12;
		ctx.strokeStyle = "#e6d3c2";
		ctx.lineWidth = 3;
		ctx.beginPath();
		ctx.moveTo(-10, -50);
		ctx.lineTo(-18, -28 + swing);
		ctx.moveTo(10, -50);
		ctx.lineTo(18, -28 - swing);
		ctx.moveTo(-6, -28);
		ctx.lineTo(-8, 6);
		ctx.moveTo(6, -28);
		ctx.lineTo(10, 6);
		ctx.stroke();
		ctx.lineWidth = 1;
	}
	ctx.restore();
}
function vignette(ctx) {
	const g = ctx.createRadialGradient(W / 2, H / 2, H * .3, W / 2, H / 2, H * .78);
	g.addColorStop(0, "rgba(0,0,0,0)");
	g.addColorStop(1, "rgba(0,0,0,0.55)");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, W, H);
}
function caption(ctx, text) {
	ctx.font = "600 32px Georgia, serif";
	ctx.textAlign = "center";
	ctx.fillStyle = "rgba(0,0,0,0.45)";
	const width = Math.min(1200, ctx.measureText(text).width + 48);
	ctx.fillRect((W - width) / 2, 628, width, 52);
	ctx.fillStyle = "#f4f1ea";
	ctx.fillText(text, W / 2, 662);
}
function drawShot(ctx, shot, local) {
	const u = clamp(local / shot.dur, 0, 1);
	if (shot.place === "space") space(ctx, local);
	else {
		sky(ctx, shot.time);
		if (shot.place === "field") field(ctx, local);
		else if (shot.place === "interior") interior(ctx, shot.accent);
		else city(ctx, local, shot.place === "rain" || shot.place === "alley", shot.accent);
		ground(ctx, shot.place, shot.time);
	}
	const base = shot.place === "space" ? H * .62 : H * .72;
	const speed = shot.action === "run" ? 220 : shot.action === "dance" ? 40 : shot.action === "stand" ? 8 : 90;
	shot.actors.forEach((kind, i) => {
		const dir = i === 0 ? 1 : -1;
		let x = W * (.28 + i * .34) + Math.sin(local * (shot.action === "dance" ? 3 : 1)) * 30 * dir;
		if (shot.action === "walk" || shot.action === "run") {
			x = (W * .15 + local * speed * dir + i * 180) % 1480 - 80;
			if (x < -40) x += 1400;
		}
		const bob = shot.action === "dance" ? Math.sin(local * 6) * 16 : Math.abs(Math.sin(local * 4)) * -6;
		const y = kind === "bird" ? H * .32 + Math.sin(local + i) * 20 : base + bob;
		actor(ctx, kind, x, y, local * (shot.action === "dance" ? 6 : 4) + i, shot.accent);
	});
	vignette(ctx);
	ctx.globalAlpha = u < .08 ? u / .08 : u > .92 ? (1 - u) / .08 : 1;
	caption(ctx, shot.caption);
	ctx.globalAlpha = 1;
}
function card(ctx, film, title, local) {
	ctx.fillStyle = "#07080c";
	ctx.fillRect(0, 0, W, H);
	ctx.textAlign = "center";
	ctx.fillStyle = "#c6f54e";
	ctx.font = "600 18px ui-sans-serif, system-ui";
	ctx.fillText(film.style.toUpperCase(), W / 2, H * .38);
	ctx.fillStyle = "#f4f1ea";
	ctx.font = "700 64px Georgia, serif";
	const words = (title ? film.title : "End").split(" ");
	ctx.fillText(words.slice(0, 5).join(" "), W / 2, H * .5);
	ctx.font = "400 24px Georgia, serif";
	ctx.fillStyle = "#b7b3aa";
	if (title) {
		const line = film.logline.length > 90 ? film.logline.slice(0, 88) + "…" : film.logline;
		ctx.fillText(line, W / 2, H * .6);
	}
	ctx.globalAlpha = ease(clamp(local / .6, 0, 1));
	ctx.globalAlpha = 1;
}
function drawFrame(ctx, film, time) {
	const { segs } = timeline(film);
	const seg = segs.find((s) => time >= s.t0 && time < s.t1) ?? segs[segs.length - 1];
	const local = time - seg.t0;
	if (seg.kind === "title") card(ctx, film, true, local);
	else if (seg.kind === "end") card(ctx, film, false, local);
	else if (seg.shot) drawShot(ctx, seg.shot, local);
}
function tone(ctx, dest, freq, when, dur, type, gain) {
	const o = ctx.createOscillator();
	const g = ctx.createGain();
	o.type = type;
	o.frequency.value = freq;
	g.gain.setValueAtTime(1e-4, when);
	g.gain.exponentialRampToValueAtTime(gain, when + .05);
	g.gain.exponentialRampToValueAtTime(1e-4, when + dur);
	o.connect(g);
	g.connect(dest);
	o.start(when);
	o.stop(when + dur + .05);
}
function score(ctx, dest, film, total) {
	const root = 110 + hash(film.title) % 8 * 8;
	const steps = [
		0,
		3,
		5,
		7,
		10
	];
	for (let t = 0; t < total; t += .5) {
		const n = steps[Math.floor(t * 2) % steps.length];
		tone(ctx, dest, root * Math.pow(2, n / 12) * (t % 4 < 2 ? 1 : 2), ctx.currentTime + t, .45, "triangle", .05);
		if (Math.floor(t) % 2 === 0) tone(ctx, dest, root / 2, ctx.currentTime + t, .9, "sine", .04);
	}
}
var FRAME = {
	W,
	H
};
async function recordFilm(film, canvas, onProgress) {
	const ctx2d = canvas.getContext("2d");
	if (!ctx2d) throw new Error("Canvas is not available in this browser.");
	const { total } = timeline(film);
	const stream = canvas.captureStream(30);
	const audio = new AudioContext();
	const dest = audio.createMediaStreamDestination();
	const master = audio.createGain();
	master.gain.value = .9;
	master.connect(dest);
	master.connect(audio.destination);
	score(audio, master, film, total);
	dest.stream.getAudioTracks().forEach((track) => stream.addTrack(track));
	const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus") ? "video/webm;codecs=vp9,opus" : MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus") ? "video/webm;codecs=vp8,opus" : "video/webm";
	const rec = new MediaRecorder(stream, {
		mimeType: mime,
		videoBitsPerSecond: 4e6
	});
	const chunks = [];
	rec.ondataavailable = (e) => {
		if (e.data.size) chunks.push(e.data);
	};
	const done = new Promise((resolve, reject) => {
		rec.onerror = () => reject(/* @__PURE__ */ new Error("Recording failed."));
		rec.onstop = () => resolve(new Blob(chunks, { type: mime }));
	});
	rec.start(200);
	const t0 = performance.now();
	await new Promise((resolve) => {
		const step = () => {
			const elapsed = (performance.now() - t0) / 1e3;
			drawFrame(ctx2d, film, Math.min(elapsed, total - .001));
			onProgress(clamp(elapsed / total, 0, 1));
			if (elapsed < total) requestAnimationFrame(step);
			else resolve();
		};
		requestAnimationFrame(step);
	});
	rec.stop();
	stream.getTracks().forEach((t) => t.stop());
	const blob = await done;
	setTimeout(() => void audio.close(), 400);
	return blob;
}
var LENGTHS = [
	15,
	30,
	45,
	60
];
var STYLES = [
	"cinematic",
	"noir",
	"gentle",
	"playful",
	"epic"
];
function Home() {
	const canvasRef = (0, import_react.useRef)(null);
	const [idea, setIdea] = (0, import_react.useState)("A rusty courier robot finds a grey cat in a rainy neon city. They dance until dawn.");
	const [seconds, setSeconds] = (0, import_react.useState)(30);
	const [style, setStyle] = (0, import_react.useState)("cinematic");
	const [scriptReady, setScriptReady] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)("idle");
	const [error, setError] = (0, import_react.useState)("");
	const [film, setFilm] = (0, import_react.useState)(null);
	const [source, setSource] = (0, import_react.useState)(null);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [videoUrl, setVideoUrl] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		studioStatus().then((s) => setScriptReady(s.script)).catch(() => setScriptReady(false));
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			if (videoUrl) URL.revokeObjectURL(videoUrl);
		};
	}, [videoUrl]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const ctx = canvas?.getContext("2d");
		if (!canvas || !ctx || film) return;
		ctx.fillStyle = "#07080c";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		ctx.fillStyle = "#c6f54e";
		ctx.font = "600 28px ui-sans-serif, system-ui";
		ctx.textAlign = "center";
		ctx.fillText("ELI SI", canvas.width / 2, canvas.height / 2 - 20);
		ctx.fillStyle = "#f4f1ea";
		ctx.font = "700 54px Georgia, serif";
		ctx.fillText("Movies Creator", canvas.width / 2, canvas.height / 2 + 48);
	}, [film]);
	async function make() {
		setError("");
		setBusy("writing");
		setProgress(0);
		if (videoUrl) URL.revokeObjectURL(videoUrl);
		setVideoUrl(null);
		try {
			const result = await writeScript({ data: {
				idea,
				seconds,
				style
			} });
			setFilm(result.film);
			setSource(result.source);
			setBusy("rendering");
			await new Promise((r) => requestAnimationFrame(() => r(null)));
			const canvas = canvasRef.current;
			if (!canvas) throw new Error("The stage is not ready.");
			const blob = await recordFilm(result.film, canvas, setProgress);
			const url = URL.createObjectURL(blob);
			setVideoUrl(url);
			const ctx = canvas.getContext("2d");
			if (ctx) drawFrame(ctx, result.film, timeline(result.film).total - .2);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not make the film.");
		} finally {
			setBusy("idle");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-[#07080c] text-[#e8e6e1]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between gap-4 border-b border-white/10 px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold tracking-tight",
				children: "ELI SI Movies Creator"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-[#c6f54e] px-3 py-1 font-semibold text-black",
					children: scriptReady ? "Grok script on" : "Local script writer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-white/15 px-3 py-1 text-[#c6f54e]",
					children: "video on"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-8 px-5 py-8 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-white/70",
						children: ["What is the film about?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: idea,
							onChange: (e) => setIdea(e.target.value),
							rows: 5,
							className: "mt-2 w-full resize-y rounded-xl border border-white/10 bg-[#12141a] px-3 py-3 text-[15px] leading-relaxed outline-none focus:border-[#c6f54e]"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm text-white/70",
							children: ["Length", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: seconds,
								onChange: (e) => setSeconds(Number(e.target.value)),
								className: "mt-2 w-full rounded-xl border border-white/10 bg-[#12141a] px-3 py-3",
								children: LENGTHS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: n,
									children: [n, " seconds"]
								}, n))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm text-white/70",
							children: ["Style", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: style,
								onChange: (e) => setStyle(e.target.value),
								className: "mt-2 w-full rounded-xl border border-white/10 bg-[#12141a] px-3 py-3",
								children: STYLES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy !== "idle",
						onClick: () => void make(),
						className: "rounded-full bg-[#c6f54e] px-5 py-3 text-sm font-semibold text-black disabled:opacity-50",
						children: busy === "writing" ? "Writing the film…" : busy === "rendering" ? "Rendering…" : "Make the film"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-white/55",
						children: ["The picture, music, and download are made in this browser. Nothing is sent to a video farm.", scriptReady ? " Grok writes the shot list when you press the button." : " If the model is unavailable, a built-in writer still builds the shots."]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-red-300",
						children: error
					}) : null,
					film ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "space-y-2 text-sm text-white/75",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "font-medium text-white",
							children: [film.title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs font-normal text-white/40",
								children: source === "grok" ? "Grok" : "Local writer"
							})]
						}), film.shots.map((shot, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-lg border border-white/10 px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[#c6f54e]",
								children: [
									shot.place,
									" · ",
									shot.time,
									" · ",
									shot.dur,
									"s"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: shot.caption })]
						}, i))]
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-2xl border border-white/10 bg-black",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: canvasRef,
							width: FRAME.W,
							height: FRAME.H,
							className: "aspect-video w-full"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1 overflow-hidden rounded-full bg-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-[#c6f54e] transition-[width]",
							style: { width: `${Math.round(progress * 100)}%` }
						})
					}),
					videoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
							src: videoUrl,
							controls: true,
							className: "aspect-video w-full rounded-2xl border border-white/10"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: videoUrl,
							download: `${(film?.title || "film").replace(/\s+/g, "-").toLowerCase()}.webm`,
							className: "inline-flex rounded-full border border-[#c6f54e] px-4 py-2 text-sm font-semibold text-[#c6f54e]",
							children: "Download video"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-white/45",
						children: busy === "rendering" ? "Recording the film now. Stay on this page until the bar fills." : "Your video will appear here."
					})
				]
			})]
		})]
	});
}
//#endregion
export { Home as component };
