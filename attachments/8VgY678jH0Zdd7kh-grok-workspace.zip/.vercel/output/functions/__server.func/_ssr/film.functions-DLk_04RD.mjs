import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/film.functions-DLk_04RD.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var PLACES = [
	"city",
	"rain",
	"alley",
	"rooftop",
	"field",
	"interior",
	"space"
];
var TIMES = [
	"dawn",
	"day",
	"dusk",
	"night"
];
var ACTORS = [
	"robot",
	"cat",
	"person",
	"bird"
];
var ACTIONS = [
	"walk",
	"dance",
	"stand",
	"run"
];
var ACCENTS = [
	"#6fd3c8",
	"#ff5a4a",
	"#ffd23f",
	"#b36bff",
	"#ff9f1c",
	"#7ad1ff"
];
function pick(list, n) {
	return list[(n % list.length + list.length) % list.length];
}
function detectActors(text) {
	const t = text.toLowerCase();
	const found = [];
	if (/robot|droid|android|courier/.test(t)) found.push("robot");
	if (/cat|kitten/.test(t)) found.push("cat");
	if (/bird|crow|owl/.test(t)) found.push("bird");
	if (/person|woman|man|girl|boy|hero|she |he /.test(t)) found.push("person");
	if (!found.length) found.push("person");
	return found.slice(0, 2);
}
function detectPlace(text, i) {
	const t = text.toLowerCase();
	if (/rain|storm|wet/.test(t)) return "rain";
	if (/neon|city|street|urban/.test(t)) return i % 2 ? "city" : "alley";
	if (/roof/.test(t)) return "rooftop";
	if (/space|star|moon|orbit/.test(t)) return "space";
	if (/room|inside|kitchen|home/.test(t)) return "interior";
	if (/field|forest|hill|beach|dawn/.test(t)) return "field";
	return pick(PLACES, i + text.length);
}
function detectTime(text, i) {
	const t = text.toLowerCase();
	if (/night|neon|midnight/.test(t)) return "night";
	if (/dawn|morning/.test(t)) return "dawn";
	if (/dusk|sunset/.test(t)) return "dusk";
	if (/day|noon|sun/.test(t)) return "day";
	return pick(TIMES, i);
}
function detectAction(text, i) {
	const t = text.toLowerCase();
	if (/danc/.test(t)) return "dance";
	if (/run|chase|sprint/.test(t)) return "run";
	if (/walk|stroll|wander/.test(t)) return "walk";
	if (/stand|wait|look|watch/.test(t)) return "stand";
	return pick(ACTIONS, i);
}
/** Always-available writer. Used when the model is unreachable. */
function writeFilmLocally(idea, seconds, style) {
	const clean = idea.replace(/\s+/g, " ").trim() || "A quiet story about finding a friend.";
	const bits = clean.split(/(?<=[.!?])\s+/).map((s) => s.trim()).filter(Boolean);
	const lines = bits.length >= 2 ? bits : [
		clean,
		"They keep going until the light changes.",
		"Something small is enough."
	];
	const count = Math.max(3, Math.min(8, Math.round(seconds / 7)));
	const dur = Math.max(4, Math.round(seconds / count));
	const actors = detectActors(clean);
	const shots = Array.from({ length: count }, (_, i) => {
		const line = lines[i % lines.length];
		return {
			dur,
			place: detectPlace(clean + " " + line, i),
			time: detectTime(clean, i),
			caption: line.replace(/[.!?]+$/, ""),
			actors: i === 0 ? actors.slice(0, 1) : actors,
			action: detectAction(clean, i),
			accent: ACCENTS[i % ACCENTS.length]
		};
	});
	return {
		title: clean.split(/[.!?]/)[0].split(" ").slice(0, 6).join(" ") || "Untitled",
		logline: clean,
		style,
		shots
	};
}
function normalizeFilm(raw, idea, seconds, style) {
	const fallback = writeFilmLocally(idea, seconds, style);
	if (!raw || typeof raw !== "object") return fallback;
	const o = raw;
	const shotsIn = Array.isArray(o.shots) ? o.shots : [];
	const shots = [];
	for (const item of shotsIn.slice(0, 8)) {
		if (!item || typeof item !== "object") continue;
		const s = item;
		const place = PLACES.includes(s.place) ? s.place : "city";
		const time = TIMES.includes(s.time) ? s.time : "night";
		const action = ACTIONS.includes(s.action) ? s.action : "walk";
		const actors = Array.isArray(s.actors) ? s.actors.filter((a) => ACTORS.includes(a)).slice(0, 2) : [];
		const caption = typeof s.caption === "string" ? s.caption.slice(0, 140) : "";
		const dur = typeof s.dur === "number" ? Math.max(3, Math.min(12, s.dur)) : 6;
		if (!caption) continue;
		shots.push({
			dur,
			place,
			time,
			caption,
			actors: actors.length ? actors : ["person"],
			action,
			accent: typeof s.accent === "string" && /^#[0-9a-fA-F]{6}$/.test(s.accent) ? s.accent : "#c6f54e"
		});
	}
	if (shots.length < 2) return fallback;
	const scale = seconds / shots.reduce((n, s) => n + s.dur, 0);
	for (const s of shots) s.dur = Math.max(3, Math.round(s.dur * scale));
	return {
		title: typeof o.title === "string" && o.title.trim() ? o.title.trim().slice(0, 80) : fallback.title,
		logline: typeof o.logline === "string" && o.logline.trim() ? o.logline.trim().slice(0, 240) : idea,
		style,
		shots
	};
}
var studioStatus_createServerFn_handler = createServerRpc({
	id: "a0eaaecac1ceaf6fd7292a87d405d9505991ebc2a46d4ccf0c3ff7bde2c02811",
	name: "studioStatus",
	filename: "src/lib/film.functions.ts"
}, (opts) => studioStatus.__executeServer(opts));
var studioStatus = createServerFn({ method: "GET" }).handler(studioStatus_createServerFn_handler, async () => {
	return { script: Boolean(process.env.XAI_API_KEY) };
});
var writeScript_createServerFn_handler = createServerRpc({
	id: "391feb01f24590587bc09bfb2d2946053c8f3d2de922fa0d6f7e69aef39510c9",
	name: "writeScript",
	filename: "src/lib/film.functions.ts"
}, (opts) => writeScript.__executeServer(opts));
var writeScript = createServerFn({ method: "POST" }).validator((input) => {
	const idea = String(input?.idea ?? "").trim().slice(0, 600);
	const seconds = [
		15,
		30,
		45,
		60
	].includes(Number(input?.seconds)) ? Number(input.seconds) : 30;
	const style = String(input?.style ?? "cinematic").slice(0, 40);
	if (idea.length < 8) throw new Error("Describe the film in a sentence or two.");
	return {
		idea,
		seconds,
		style
	};
}).handler(writeScript_createServerFn_handler, async ({ data }) => {
	const local = () => ({
		film: writeFilmLocally(data.idea, data.seconds, data.style),
		source: "local"
	});
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return local();
	const prompt = `Write a short silent film as JSON only. Idea: ${data.idea}
Style: ${data.style}. Target length about ${data.seconds} seconds.
Schema: {"title":string,"logline":string,"shots":[{"dur":number,"place":"city"|"rain"|"alley"|"rooftop"|"field"|"interior"|"space","time":"dawn"|"day"|"dusk"|"night","caption":string,"actors":array of "robot"|"cat"|"person"|"bird","action":"walk"|"dance"|"stand"|"run","accent":"#rrggbb"}]}
Use 3 to 6 shots. Captions are short on-screen lines, not camera directions. No markdown.`;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .7,
				max_tokens: 900,
				messages: [{
					role: "user",
					content: prompt
				}]
			})
		});
		if (!res.ok) return local();
		const text = (await res.json()).choices?.[0]?.message?.content ?? "";
		const start = text.indexOf("{");
		const end = text.lastIndexOf("}");
		if (start < 0 || end <= start) return local();
		return {
			film: normalizeFilm(JSON.parse(text.slice(start, end + 1)), data.idea, data.seconds, data.style),
			source: "grok"
		};
	} catch {
		return local();
	}
});
//#endregion
export { studioStatus_createServerFn_handler, writeScript_createServerFn_handler };
