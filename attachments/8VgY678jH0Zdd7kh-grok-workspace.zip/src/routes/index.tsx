import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { studioStatus, writeScript } from "@/lib/film.functions";
import type { Film } from "@/lib/film-types";
import { FRAME, drawFrame, recordFilm, timeline } from "@/lib/render-film";

export const Route = createFileRoute("/")({ component: Home });

const LENGTHS = [15, 30, 45, 60];
const STYLES = ["cinematic", "noir", "gentle", "playful", "epic"];

function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [idea, setIdea] = useState(
    "A rusty courier robot finds a grey cat in a rainy neon city. They dance until dawn.",
  );
  const [seconds, setSeconds] = useState(30);
  const [style, setStyle] = useState("cinematic");
  const [scriptReady, setScriptReady] = useState(false);
  const [busy, setBusy] = useState<"idle" | "writing" | "rendering">("idle");
  const [error, setError] = useState("");
  const [film, setFilm] = useState<Film | null>(null);
  const [source, setSource] = useState<"grok" | "local" | null>(null);
  const [progress, setProgress] = useState(0);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  useEffect(() => {
    void studioStatus().then((s) => setScriptReady(s.script)).catch(() => setScriptReady(false));
  }, []);

  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx || film) return;
    ctx.fillStyle = "#07080c";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#c6f54e";
    ctx.font = "600 28px ui-sans-serif, system-ui";
    ctx.textAlign = "center";
    ctx.fillText("ELI SI", canvas.width / 2, canvas.height / 2 - 20);
    ctx.fillStyle = "#f4f1ea";
    ctx.font = "700 54px Georgia, serif";
    ctx.fillText("Movies Creator", canvas.width / 2, canvas.height / 2 + 48);
  }, [film]);

  async function make() {
    setError("");
    setBusy("writing");
    setProgress(0);
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setVideoUrl(null);
    try {
      const result = await writeScript({ data: { idea, seconds, style } });
      setFilm(result.film);
      setSource(result.source);
      setBusy("rendering");
      await new Promise((r) => requestAnimationFrame(() => r(null)));
      const canvas = canvasRef.current;
      if (!canvas) throw new Error("The stage is not ready.");
      const blob = await recordFilm(result.film, canvas, setProgress);
      const url = URL.createObjectURL(blob);
      setVideoUrl(url);
      const ctx = canvas.getContext("2d");
      if (ctx) drawFrame(ctx, result.film, timeline(result.film).total - 0.2);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not make the film.");
    } finally {
      setBusy("idle");
    }
  }

  return (
    <main className="min-h-screen bg-[#07080c] text-[#e8e6e1]">
      <header className="flex items-center justify-between gap-4 border-b border-white/10 px-5 py-4">
        <h1 className="text-lg font-semibold tracking-tight">ELI SI Movies Creator</h1>
        <div className="flex items-center gap-2 text-xs">
          <span className="rounded-full bg-[#c6f54e] px-3 py-1 font-semibold text-black">
            {scriptReady ? "Grok script on" : "Local script writer"}
          </span>
          <span className="rounded-full border border-white/15 px-3 py-1 text-[#c6f54e]">video on</span>
        </div>
      </header>

      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-8 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
        <section className="space-y-4">
          <label className="block text-sm text-white/70">
            What is the film about?
            <textarea
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              rows={5}
              className="mt-2 w-full resize-y rounded-xl border border-white/10 bg-[#12141a] px-3 py-3 text-[15px] leading-relaxed outline-none focus:border-[#c6f54e]"
            />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="text-sm text-white/70">
              Length
              <select
                value={seconds}
                onChange={(e) => setSeconds(Number(e.target.value))}
                className="mt-2 w-full rounded-xl border border-white/10 bg-[#12141a] px-3 py-3"
              >
                {LENGTHS.map((n) => (
                  <option key={n} value={n}>
                    {n} seconds
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm text-white/70">
              Style
              <select
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                className="mt-2 w-full rounded-xl border border-white/10 bg-[#12141a] px-3 py-3"
              >
                {STYLES.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </label>
          </div>
          <button
            type="button"
            disabled={busy !== "idle"}
            onClick={() => void make()}
            className="rounded-full bg-[#c6f54e] px-5 py-3 text-sm font-semibold text-black disabled:opacity-50"
          >
            {busy === "writing" ? "Writing the film…" : busy === "rendering" ? "Rendering…" : "Make the film"}
          </button>
          <p className="text-sm text-white/55">
            The picture, music, and download are made in this browser. Nothing is sent to a video farm.
            {scriptReady
              ? " Grok writes the shot list when you press the button."
              : " If the model is unavailable, a built-in writer still builds the shots."}
          </p>
          {error ? <p className="text-sm text-red-300">{error}</p> : null}
          {film ? (
            <ol className="space-y-2 text-sm text-white/75">
              <li className="font-medium text-white">
                {film.title}
                <span className="ml-2 text-xs font-normal text-white/40">{source === "grok" ? "Grok" : "Local writer"}</span>
              </li>
              {film.shots.map((shot, i) => (
                <li key={i} className="rounded-lg border border-white/10 px-3 py-2">
                  <span className="text-[#c6f54e]">
                    {shot.place} · {shot.time} · {shot.dur}s
                  </span>
                  <div>{shot.caption}</div>
                </li>
              ))}
            </ol>
          ) : null}
        </section>

        <section className="space-y-3">
          <div className="overflow-hidden rounded-2xl border border-white/10 bg-black">
            <canvas ref={canvasRef} width={FRAME.W} height={FRAME.H} className="aspect-video w-full" />
          </div>
          <div className="h-1 overflow-hidden rounded-full bg-white/10">
            <div className="h-full bg-[#c6f54e] transition-[width]" style={{ width: `${Math.round(progress * 100)}%` }} />
          </div>
          {videoUrl ? (
            <div className="space-y-3">
              <video src={videoUrl} controls className="aspect-video w-full rounded-2xl border border-white/10" />
              <a
                href={videoUrl}
                download={`${(film?.title || "film").replace(/\s+/g, "-").toLowerCase()}.webm`}
                className="inline-flex rounded-full border border-[#c6f54e] px-4 py-2 text-sm font-semibold text-[#c6f54e]"
              >
                Download video
              </a>
            </div>
          ) : (
            <p className="text-sm text-white/45">
              {busy === "rendering" ? "Recording the film now. Stay on this page until the bar fills." : "Your video will appear here."}
            </p>
          )}
        </section>
      </div>
    </main>
  );
}
