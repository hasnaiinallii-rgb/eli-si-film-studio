import type { Actor, Film, Place, Shot, TimeOfDay } from "./film-types";

const W = 1280;
const H = 720;

const SKY: Record<TimeOfDay, [string, string, string]> = {
  dawn: ["#2b3a67", "#d98e73", "#ffd8a8"],
  day: ["#3d7ec9", "#8ec5f0", "#e7f4ff"],
  dusk: ["#24183f", "#c2506b", "#ffb36b"],
  night: ["#050712", "#0c1636", "#1a2758"],
};

function clamp(v: number, a: number, b: number) {
  return Math.min(b, Math.max(a, v));
}
function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}
function ease(t: number) {
  return t * t * (3 - 2 * t);
}
function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

type Seg = { kind: "title" | "shot" | "end"; shot?: Shot; t0: number; t1: number };

export function timeline(film: Film) {
  const segs: Seg[] = [];
  let t = 0;
  segs.push({ kind: "title", t0: t, t1: (t += 3) });
  for (const shot of film.shots) segs.push({ kind: "shot", shot, t0: t, t1: (t += shot.dur) });
  segs.push({ kind: "end", t0: t, t1: (t += 3) });
  return { segs, total: t };
}

function sky(ctx: CanvasRenderingContext2D, time: TimeOfDay) {
  const [a, b, c] = SKY[time];
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, a);
  g.addColorStop(0.55, b);
  g.addColorStop(1, c);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  if (time === "night" || time === "dusk") {
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    for (let i = 0; i < 40; i++) {
      const x = (i * 97) % W;
      const y = (i * 53) % (H * 0.55);
      ctx.globalAlpha = 0.3 + ((i * 17) % 7) / 10;
      ctx.fillRect(x, y, i % 5 === 0 ? 2 : 1, i % 5 === 0 ? 2 : 1);
    }
    ctx.globalAlpha = 1;
  }
}

function ground(ctx: CanvasRenderingContext2D, place: Place, time: TimeOfDay) {
  const y = H * 0.72;
  ctx.fillStyle = time === "day" || time === "dawn" ? "#2c3330" : "#0b0d12";
  if (place === "field") ctx.fillStyle = time === "night" ? "#142016" : "#3d6b3a";
  if (place === "space") ctx.fillStyle = "#05060c";
  ctx.fillRect(0, y, W, H - y);
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.beginPath();
  ctx.moveTo(0, y);
  ctx.lineTo(W, y);
  ctx.stroke();
}

function city(ctx: CanvasRenderingContext2D, t: number, wet: boolean, accent: string) {
  const base = H * 0.72;
  for (let i = 0; i < 14; i++) {
    const x = (i * 110 - ((t * 18) % 110)) % (W + 140) - 40;
    const h = 90 + ((i * 47) % 220);
    ctx.fillStyle = i % 2 ? "#12151c" : "#1a1f2b";
    ctx.fillRect(x, base - h, 78, h);
    ctx.fillStyle = accent;
    for (let wy = base - h + 12; wy < base - 10; wy += 18) {
      for (let wx = x + 10; wx < x + 68; wx += 16) {
        ctx.globalAlpha = ((i + wy + Math.floor(t)) % 5 === 0) ? 0.9 : 0.25;
        ctx.fillRect(wx, wy, 8, 6);
      }
    }
    ctx.globalAlpha = 1;
  }
  if (wet) {
    ctx.fillStyle = "rgba(120,160,255,0.18)";
    ctx.fillRect(0, base, W, 18);
    for (let i = 0; i < 80; i++) {
      const x = (i * 37 + t * 420) % W;
      const y = ((i * 91 + t * 260) % (H * 0.45)) + 20;
      ctx.strokeStyle = "rgba(200,220,255,0.35)";
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x - 2, y + 14);
      ctx.stroke();
    }
  }
}

function field(ctx: CanvasRenderingContext2D, t: number) {
  const base = H * 0.72;
  ctx.fillStyle = "#1d3a22";
  for (let i = 0; i < 60; i++) {
    const x = (i * 28 + Math.sin(t + i) * 4) % W;
    ctx.beginPath();
    ctx.moveTo(x, base);
    ctx.quadraticCurveTo(x + 6, base - 28, x + Math.sin(t * 2 + i) * 8, base - 46);
    ctx.strokeStyle = i % 2 ? "#6ea85a" : "#2f6a38";
    ctx.stroke();
  }
}

function interior(ctx: CanvasRenderingContext2D, accent: string) {
  ctx.fillStyle = "#1a1410";
  ctx.fillRect(80, 80, W - 160, H * 0.72 - 80);
  ctx.strokeStyle = accent;
  ctx.globalAlpha = 0.5;
  ctx.strokeRect(100, 100, W - 200, H * 0.72 - 120);
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#3a2a18";
  ctx.fillRect(160, H * 0.5, 220, H * 0.72 - H * 0.5);
  const g = ctx.createRadialGradient(W * 0.7, 160, 10, W * 0.7, 200, 280);
  g.addColorStop(0, "rgba(255,196,120,0.35)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

function space(ctx: CanvasRenderingContext2D, t: number) {
  ctx.fillStyle = "#070912";
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = "#fff";
  for (let i = 0; i < 90; i++) {
    const x = (i * 137 + t * (8 + (i % 5))) % W;
    const y = (i * 89) % H;
    ctx.globalAlpha = 0.3 + (i % 5) / 8;
    ctx.fillRect(x, y, 2, 2);
  }
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#c9b6ff";
  ctx.beginPath();
  ctx.arc(W * 0.78, H * 0.28, 70, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#070912";
  ctx.beginPath();
  ctx.arc(W * 0.78 + 28, H * 0.28 - 8, 58, 0, Math.PI * 2);
  ctx.fill();
}

function actor(ctx: CanvasRenderingContext2D, kind: Actor, x: number, y: number, phase: number, accent: string) {
  ctx.save();
  ctx.translate(x, y);
  if (kind === "robot") {
    ctx.fillStyle = "#8d939c";
    ctx.fillRect(-22, -78, 44, 52);
    ctx.fillStyle = accent;
    ctx.fillRect(-14, -64, 28, 10);
    ctx.fillStyle = "#5c636c";
    ctx.fillRect(-26, -26, 52, 36);
    const swing = Math.sin(phase) * 10;
    ctx.fillRect(-30, -20 + swing, 8, 28);
    ctx.fillRect(22, -20 - swing, 8, 28);
    ctx.fillRect(-16, 10, 10, 26 + Math.abs(swing));
    ctx.fillRect(6, 10, 10, 26 + Math.abs(swing) * 0.4);
    ctx.fillStyle = "#c5ccd4";
    ctx.fillRect(-8, -92, 16, 14);
  } else if (kind === "cat") {
    ctx.fillStyle = "#9aa0a8";
    ctx.beginPath();
    ctx.ellipse(0, -18, 28, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(22, -30, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#6e747c";
    ctx.beginPath();
    ctx.moveTo(14, -40);
    ctx.lineTo(18, -52);
    ctx.lineTo(26, -40);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(24, -38);
    ctx.lineTo(32, -50);
    ctx.lineTo(34, -36);
    ctx.fill();
    ctx.strokeStyle = "#9aa0a8";
    ctx.beginPath();
    ctx.moveTo(-24, -18);
    ctx.quadraticCurveTo(-40, -40 + Math.sin(phase) * 8, -18, -8);
    ctx.stroke();
    ctx.fillStyle = accent;
    ctx.fillRect(26, -32, 3, 3);
  } else if (kind === "bird") {
    ctx.strokeStyle = accent;
    ctx.lineWidth = 3;
    const f = Math.sin(phase * 2) * 16;
    ctx.beginPath();
    ctx.moveTo(-20, f);
    ctx.quadraticCurveTo(0, -18, 20, -f);
    ctx.stroke();
    ctx.lineWidth = 1;
  } else {
    ctx.fillStyle = "#e6d3c2";
    ctx.beginPath();
    ctx.arc(0, -78, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = accent;
    ctx.fillRect(-12, -64, 24, 36);
    const swing = Math.sin(phase) * 12;
    ctx.strokeStyle = "#e6d3c2";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-10, -50);
    ctx.lineTo(-18, -28 + swing);
    ctx.moveTo(10, -50);
    ctx.lineTo(18, -28 - swing);
    ctx.moveTo(-6, -28);
    ctx.lineTo(-8, 6);
    ctx.moveTo(6, -28);
    ctx.lineTo(10, 6);
    ctx.stroke();
    ctx.lineWidth = 1;
  }
  ctx.restore();
}

function vignette(ctx: CanvasRenderingContext2D) {
  const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.78);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,0.55)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

function caption(ctx: CanvasRenderingContext2D, text: string) {
  ctx.font = "600 32px Georgia, serif";
  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(0,0,0,0.45)";
  const width = Math.min(W - 80, ctx.measureText(text).width + 48);
  ctx.fillRect((W - width) / 2, H - 92, width, 52);
  ctx.fillStyle = "#f4f1ea";
  ctx.fillText(text, W / 2, H - 58);
}

function drawShot(ctx: CanvasRenderingContext2D, shot: Shot, local: number) {
  const u = clamp(local / shot.dur, 0, 1);
  if (shot.place === "space") space(ctx, local);
  else {
    sky(ctx, shot.time);
    if (shot.place === "field") field(ctx, local);
    else if (shot.place === "interior") interior(ctx, shot.accent);
    else city(ctx, local, shot.place === "rain" || shot.place === "alley", shot.accent);
    ground(ctx, shot.place, shot.time);
  }
  const base = shot.place === "space" ? H * 0.62 : H * 0.72;
  const speed = shot.action === "run" ? 220 : shot.action === "dance" ? 40 : shot.action === "stand" ? 8 : 90;
  shot.actors.forEach((kind, i) => {
    const dir = i === 0 ? 1 : -1;
    let x = W * (0.28 + i * 0.34) + Math.sin(local * (shot.action === "dance" ? 3 : 1)) * 30 * dir;
    if (shot.action === "walk" || shot.action === "run") {
      x = ((W * 0.15 + local * speed * dir + i * 180) % (W + 200)) - 80;
      if (x < -40) x += W + 120;
    }
    const bob = shot.action === "dance" ? Math.sin(local * 6) * 16 : Math.abs(Math.sin(local * 4)) * -6;
    const y = kind === "bird" ? H * 0.32 + Math.sin(local + i) * 20 : base + bob;
    actor(ctx, kind, x, y, local * (shot.action === "dance" ? 6 : 4) + i, shot.accent);
  });
  vignette(ctx);
  const fade = u < 0.08 ? u / 0.08 : u > 0.92 ? (1 - u) / 0.08 : 1;
  ctx.globalAlpha = fade;
  caption(ctx, shot.caption);
  ctx.globalAlpha = 1;
}

function card(ctx: CanvasRenderingContext2D, film: Film, title: boolean, local: number) {
  ctx.fillStyle = "#07080c";
  ctx.fillRect(0, 0, W, H);
  ctx.textAlign = "center";
  ctx.fillStyle = "#c6f54e";
  ctx.font = "600 18px ui-sans-serif, system-ui";
  ctx.fillText(film.style.toUpperCase(), W / 2, H * 0.38);
  ctx.fillStyle = "#f4f1ea";
  ctx.font = "700 64px Georgia, serif";
  const words = (title ? film.title : "End").split(" ");
  ctx.fillText(words.slice(0, 5).join(" "), W / 2, H * 0.5);
  ctx.font = "400 24px Georgia, serif";
  ctx.fillStyle = "#b7b3aa";
  if (title) {
    const line = film.logline.length > 90 ? film.logline.slice(0, 88) + "…" : film.logline;
    ctx.fillText(line, W / 2, H * 0.6);
  }
  ctx.globalAlpha = ease(clamp(local / 0.6, 0, 1));
  ctx.globalAlpha = 1;
}

export function drawFrame(ctx: CanvasRenderingContext2D, film: Film, time: number) {
  const { segs } = timeline(film);
  const seg = segs.find((s) => time >= s.t0 && time < s.t1) ?? segs[segs.length - 1]!;
  const local = time - seg.t0;
  if (seg.kind === "title") card(ctx, film, true, local);
  else if (seg.kind === "end") card(ctx, film, false, local);
  else if (seg.shot) drawShot(ctx, seg.shot, local);
}

function tone(ctx: AudioContext, dest: AudioNode, freq: number, when: number, dur: number, type: OscillatorType, gain: number) {
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(gain, when + 0.05);
  g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
  o.connect(g);
  g.connect(dest);
  o.start(when);
  o.stop(when + dur + 0.05);
}

export function score(ctx: AudioContext, dest: AudioNode, film: Film, total: number) {
  const root = 110 + (hash(film.title) % 8) * 8;
  const steps = [0, 3, 5, 7, 10];
  for (let t = 0; t < total; t += 0.5) {
    const n = steps[Math.floor(t * 2) % steps.length]!;
    const freq = root * Math.pow(2, n / 12) * (t % 4 < 2 ? 1 : 2);
    tone(ctx, dest, freq, ctx.currentTime + t, 0.45, "triangle", 0.05);
    if (Math.floor(t) % 2 === 0) tone(ctx, dest, root / 2, ctx.currentTime + t, 0.9, "sine", 0.04);
  }
}

export const FRAME = { W, H };

export async function recordFilm(
  film: Film,
  canvas: HTMLCanvasElement,
  onProgress: (p: number) => void,
): Promise<Blob> {
  const ctx2d = canvas.getContext("2d");
  if (!ctx2d) throw new Error("Canvas is not available in this browser.");
  const { total } = timeline(film);
  const stream = canvas.captureStream(30);
  const audio = new AudioContext();
  const dest = audio.createMediaStreamDestination();
  const master = audio.createGain();
  master.gain.value = 0.9;
  master.connect(dest);
  master.connect(audio.destination);
  score(audio, master, film, total);
  dest.stream.getAudioTracks().forEach((track) => stream.addTrack(track));

  const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")
    ? "video/webm;codecs=vp9,opus"
    : MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")
      ? "video/webm;codecs=vp8,opus"
      : "video/webm";
  const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 4_000_000 });
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size) chunks.push(e.data);
  };
  const done = new Promise<Blob>((resolve, reject) => {
    rec.onerror = () => reject(new Error("Recording failed."));
    rec.onstop = () => resolve(new Blob(chunks, { type: mime }));
  });
  rec.start(200);

  const t0 = performance.now();
  await new Promise<void>((resolve) => {
    const step = () => {
      const elapsed = (performance.now() - t0) / 1000;
      drawFrame(ctx2d, film, Math.min(elapsed, total - 0.001));
      onProgress(clamp(elapsed / total, 0, 1));
      if (elapsed < total) requestAnimationFrame(step);
      else resolve();
    };
    requestAnimationFrame(step);
  });
  rec.stop();
  stream.getTracks().forEach((t) => t.stop());
  const blob = await done;
  setTimeout(() => void audio.close(), 400);
  return blob;
}
