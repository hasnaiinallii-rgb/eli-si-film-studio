import type { Action, Actor, Film, Place, Shot, TimeOfDay } from "./film-types";
import { ACTIONS, ACTORS, PLACES, TIMES } from "./film-types";

const ACCENTS = ["#6fd3c8", "#ff5a4a", "#ffd23f", "#b36bff", "#ff9f1c", "#7ad1ff"];

function pick<T>(list: T[], n: number): T {
  return list[((n % list.length) + list.length) % list.length]!;
}

function detectActors(text: string): Actor[] {
  const t = text.toLowerCase();
  const found: Actor[] = [];
  if (/robot|droid|android|courier/.test(t)) found.push("robot");
  if (/cat|kitten/.test(t)) found.push("cat");
  if (/bird|crow|owl/.test(t)) found.push("bird");
  if (/person|woman|man|girl|boy|hero|she |he /.test(t)) found.push("person");
  if (!found.length) found.push("person");
  return found.slice(0, 2);
}

function detectPlace(text: string, i: number): Place {
  const t = text.toLowerCase();
  if (/rain|storm|wet/.test(t)) return "rain";
  if (/neon|city|street|urban/.test(t)) return i % 2 ? "city" : "alley";
  if (/roof/.test(t)) return "rooftop";
  if (/space|star|moon|orbit/.test(t)) return "space";
  if (/room|inside|kitchen|home/.test(t)) return "interior";
  if (/field|forest|hill|beach|dawn/.test(t)) return "field";
  return pick(PLACES, i + text.length);
}

function detectTime(text: string, i: number): TimeOfDay {
  const t = text.toLowerCase();
  if (/night|neon|midnight/.test(t)) return "night";
  if (/dawn|morning/.test(t)) return "dawn";
  if (/dusk|sunset/.test(t)) return "dusk";
  if (/day|noon|sun/.test(t)) return "day";
  return pick(TIMES, i);
}

function detectAction(text: string, i: number): Action {
  const t = text.toLowerCase();
  if (/danc/.test(t)) return "dance";
  if (/run|chase|sprint/.test(t)) return "run";
  if (/walk|stroll|wander/.test(t)) return "walk";
  if (/stand|wait|look|watch/.test(t)) return "stand";
  return pick(ACTIONS, i);
}

/** Always-available writer. Used when the model is unreachable. */
export function writeFilmLocally(idea: string, seconds: number, style: string): Film {
  const clean = idea.replace(/\s+/g, " ").trim() || "A quiet story about finding a friend.";
  const bits = clean
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);
  const lines = bits.length >= 2 ? bits : [clean, "They keep going until the light changes.", "Something small is enough."];
  const count = Math.max(3, Math.min(8, Math.round(seconds / 7)));
  const dur = Math.max(4, Math.round(seconds / count));
  const actors = detectActors(clean);
  const shots: Shot[] = Array.from({ length: count }, (_, i) => {
    const line = lines[i % lines.length]!;
    return {
      dur,
      place: detectPlace(clean + " " + line, i),
      time: detectTime(clean, i),
      caption: line.replace(/[.!?]+$/, ""),
      actors: i === 0 ? actors.slice(0, 1) : actors,
      action: detectAction(clean, i),
      accent: ACCENTS[i % ACCENTS.length]!,
    };
  });
  const title = clean.split(/[.!?]/)[0]!.split(" ").slice(0, 6).join(" ");
  return {
    title: title || "Untitled",
    logline: clean,
    style,
    shots,
  };
}

export function normalizeFilm(raw: unknown, idea: string, seconds: number, style: string): Film {
  const fallback = writeFilmLocally(idea, seconds, style);
  if (!raw || typeof raw !== "object") return fallback;
  const o = raw as Record<string, unknown>;
  const shotsIn = Array.isArray(o.shots) ? o.shots : [];
  const shots: Shot[] = [];
  for (const item of shotsIn.slice(0, 8)) {
    if (!item || typeof item !== "object") continue;
    const s = item as Record<string, unknown>;
    const place = PLACES.includes(s.place as Place) ? (s.place as Place) : "city";
    const time = TIMES.includes(s.time as TimeOfDay) ? (s.time as TimeOfDay) : "night";
    const action = ACTIONS.includes(s.action as Action) ? (s.action as Action) : "walk";
    const actors = Array.isArray(s.actors)
      ? s.actors.filter((a): a is Actor => ACTORS.includes(a as Actor)).slice(0, 2)
      : [];
    const caption = typeof s.caption === "string" ? s.caption.slice(0, 140) : "";
    const dur = typeof s.dur === "number" ? Math.max(3, Math.min(12, s.dur)) : 6;
    if (!caption) continue;
    shots.push({
      dur,
      place,
      time,
      caption,
      actors: actors.length ? actors : ["person"],
      action,
      accent: typeof s.accent === "string" && /^#[0-9a-fA-F]{6}$/.test(s.accent) ? s.accent : "#c6f54e",
    });
  }
  if (shots.length < 2) return fallback;
  const total = shots.reduce((n, s) => n + s.dur, 0);
  const scale = seconds / total;
  for (const s of shots) s.dur = Math.max(3, Math.round(s.dur * scale));
  return {
    title: typeof o.title === "string" && o.title.trim() ? o.title.trim().slice(0, 80) : fallback.title,
    logline: typeof o.logline === "string" && o.logline.trim() ? o.logline.trim().slice(0, 240) : idea,
    style,
    shots,
  };
}
