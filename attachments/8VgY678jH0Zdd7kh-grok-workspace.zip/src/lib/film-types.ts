export type TimeOfDay = "dawn" | "day" | "dusk" | "night";
export type Place = "city" | "rain" | "alley" | "rooftop" | "field" | "interior" | "space";
export type Actor = "robot" | "cat" | "person" | "bird";
export type Action = "walk" | "dance" | "stand" | "run";

export type Shot = {
  dur: number;
  place: Place;
  time: TimeOfDay;
  caption: string;
  actors: Actor[];
  action: Action;
  accent: string;
};

export type Film = {
  title: string;
  logline: string;
  style: string;
  shots: Shot[];
};

export const PLACES: Place[] = ["city", "rain", "alley", "rooftop", "field", "interior", "space"];
export const TIMES: TimeOfDay[] = ["dawn", "day", "dusk", "night"];
export const ACTORS: Actor[] = ["robot", "cat", "person", "bird"];
export const ACTIONS: Action[] = ["walk", "dance", "stand", "run"];
