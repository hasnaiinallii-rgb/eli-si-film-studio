import { createServerFn } from "@tanstack/react-start";
import { normalizeFilm, writeFilmLocally } from "./write-film";

export const studioStatus = createServerFn({ method: "GET" }).handler(async () => {
  return { script: Boolean(process.env.XAI_API_KEY) };
});

export const writeScript = createServerFn({ method: "POST" })
  .validator((input: { idea: string; seconds: number; style: string }) => {
    const idea = String(input?.idea ?? "").trim().slice(0, 600);
    const seconds = [15, 30, 45, 60].includes(Number(input?.seconds)) ? Number(input.seconds) : 30;
    const style = String(input?.style ?? "cinematic").slice(0, 40);
    if (idea.length < 8) throw new Error("Describe the film in a sentence or two.");
    return { idea, seconds, style };
  })
  .handler(async ({ data }) => {
    const local = () => ({
      film: writeFilmLocally(data.idea, data.seconds, data.style),
      source: "local" as const,
    });
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return local();

    const prompt = `Write a short silent film as JSON only. Idea: ${data.idea}
Style: ${data.style}. Target length about ${data.seconds} seconds.
Schema: {"title":string,"logline":string,"shots":[{"dur":number,"place":"city"|"rain"|"alley"|"rooftop"|"field"|"interior"|"space","time":"dawn"|"day"|"dusk"|"night","caption":string,"actors":array of "robot"|"cat"|"person"|"bird","action":"walk"|"dance"|"stand"|"run","accent":"#rrggbb"}]}
Use 3 to 6 shots. Captions are short on-screen lines, not camera directions. No markdown.`;

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.7,
          max_tokens: 900,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      if (!res.ok) return local();
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const text = body.choices?.[0]?.message?.content ?? "";
      const start = text.indexOf("{");
      const end = text.lastIndexOf("}");
      if (start < 0 || end <= start) return local();
      const parsed = JSON.parse(text.slice(start, end + 1)) as unknown;
      return {
        film: normalizeFilm(parsed, data.idea, data.seconds, data.style),
        source: "grok" as const,
      };
    } catch {
      return local();
    }
  });
